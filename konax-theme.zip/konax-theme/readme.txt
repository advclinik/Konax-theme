--- Konax Theme ---
A clean and simple child theme eith lateral nevigation for BuddyPress 1.5+. konax uses the BuddyPress default theme as its parent theme. BuddyPress must be active for Konax to function.


--- Installation ---
The theme is bundled with BuddyPress. After activating the plugin, BuddyPress Default will be added to the "Appearance > Themes" menu in your WordPress admin area.


For help with Konax Theme, or for more information, please visit go to http://advclinik.com/

--- Installation ---
Upload and activate the Konax theme under "Appearance > Themes" menu in your WordPress admin area.

--- Getting Started with Konax Theme ---
Go to "Appearance > Theme Options" to configure the theme

	-custom logo: upload your logo and paste the url in the form. Logo size is set up at 600x45 px.

	-welcome image: upload your image and paste the url in the form. image size is set up at 300x200 px.

	-welcome title: just type your welcome title.

	-welcome message: just type your welcome message.

	-tracking code: paste your tracking code
   

--- Credits ---


--- Changelog ---
1.0 initial release

1.2 fix minor bugs